def bar():
    print("Hi, I'm and imported class")