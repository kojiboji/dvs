VID_EXT = '.avi'
REGION = 'us-west-1'
BUCKET_PRE = 'dvs-pre'
BUCKET_STITCH = 'dvs-stitch'
DIR_STITCH = '/tmp/stitch/'
EXPIRES_IN = 3600